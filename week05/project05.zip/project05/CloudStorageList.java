/**
*Program that holds onrecord data.
*
*@author Ella Seaman - CPSC-1220
*@version 09/18/2021
*/
import java.util.Arrays;
/**
*import java array functionality.
*/
import java.io.File;
/**
*import java file read functionality.
*/
import java.util.Scanner;
/**
*import java scanner functionality.
*/
import java.io.FileNotFoundException;
/**
*import java file not found functionality.
*/
public class CloudStorageList {
// instance variables
   private CloudStorage[] cloudList;
   private String[] invalidRecords;  
   
   /**
   * constructor.
   *  
   */
   public CloudStorageList() {
   
      cloudList = new CloudStorage[0];
      invalidRecords = new String[0];
   }

   /**
   * Gets the array of cloud cloudList.
   *@return returns cloudList array.
   */
   public CloudStorage[] getCloudStorageArray() {
      return cloudList;
      
   }
   
   /**
   * Gets the array of invalid records.
   *@return returns recordsarray.
   */
   public String[] getInvalidRecordsArray() {
      return invalidRecords;
   }
   
   /**
   * method that expands cloud storage array.
   *@param cloudObject cloudList in.
   */
   public void addCloudStorage(CloudStorage cloudObject) {
      cloudList = Arrays.copyOf(cloudList, cloudList.length + 1);
      cloudList[cloudList.length - 1] = cloudObject;
   }
   
   /**
   * method that expands records array.
   *@param record records in.
   */
   public void addInvalidRecord(String record) {
      invalidRecords = Arrays.copyOf(invalidRecords, invalidRecords.length + 1);
      invalidRecords[invalidRecords.length - 1] = record;
   }
   
   /**
   * method reads files and throws exception for files not found.
   *@param fileNameIn file name in.
   *@throws FileNotFoundException when file not found
   */
   public void readFile(String fileNameIn) throws FileNotFoundException {
      Scanner scanFile = new Scanner(new File(fileNameIn));
      while (scanFile.hasNext()) {
         String line = scanFile.nextLine();
         
         Scanner recordScanner = new Scanner(line);
         
         recordScanner.useDelimiter(",");
         
         char character = recordScanner.next().charAt(0);
         
         String name = recordScanner.next();
         
         double baseStorageCost = Double.parseDouble(recordScanner.next());
         
         CloudStorage cloudObject;
         
         switch(character) {
            case 'D':
               double serverCost = Double.parseDouble(recordScanner.next());
               
               cloudObject = new DedicatedCloud(name, 
                          baseStorageCost, serverCost);
               
               addCloudStorage(cloudObject);
               
               break;
               
            case 'C':
               
               double dataStored = Double.parseDouble(recordScanner.next());
               
               double dataLimit = Double.parseDouble(recordScanner.next());
               
               cloudObject = new PublicCloud(name, 
                           baseStorageCost, dataStored, dataLimit);
               
               addCloudStorage(cloudObject);
               
               break;
                
            case 'S':
               
               dataStored = Double.parseDouble(recordScanner.next());
               
               dataLimit = Double.parseDouble(recordScanner.next());
               
               cloudObject = new SharedCloud(name, 
                           baseStorageCost, dataStored, dataLimit);
               
               addCloudStorage(cloudObject);
               
               break;
            
            case 'P':
               
               dataStored = Double.parseDouble(recordScanner.next());
               
               dataLimit = Double.parseDouble(recordScanner.next());
               
               cloudObject = new PersonalCloud(name, 
                           baseStorageCost, dataStored, dataLimit);
               
               addCloudStorage(cloudObject);
               
               break;
            
            default:
               
               addInvalidRecord(name);
               
               break;
            
         }
         
      }
   
   }
   
   
   
   /**
   * method to generate report in standard form.
   *
   * @return report cloudList.
   */
   
   public String generateReport() {

      String report;

      report = "-------------------------------" 
         + "\nMonthly Cloud Storage Report"
         + "\n-------------------------------";

      for (CloudStorage cloudObject : cloudList) {

         report += "\n" + cloudList + "\n";

      }

      return report;

   }
   
   /**
   * method to generate report sorted by name.
   *
   * @return report is the report
   */

   public String generateReportByName() {

      String report;

      report = "\n-----------------------------------------" 
         + "\nMonthly Cloud Storage Report (by Name)"
         + "\n-----------------------------------------";

      Arrays.sort(getCloudStorageArray());

      for (CloudStorage cloudObject : cloudList) {

         report += "\n" + cloudObject + "\n";

      }

      return report;

   }
    
  
   /**
   * Method to generate report sorted by monthly Cost.
   *
   * @return report is the report
   */

   public String generateReportByMonthlyCost() {

      String report;

      report = "\n-------------------------------------------------"
                + "\nMonthly Cloud Storage Report (by Monthly Cost)"
                + "\n-------------------------------------------------";

      Arrays.sort(getCloudStorageArray(), new MonthlyCostComparator());

      for (CloudStorage cloudObject : cloudList) {

         report += "\n" + cloudObject + "\n";

      }

      return report;

   }
   
   
}
    
