/**
*Program that holds online data.
*
*@author Ella Seaman - CPSC-1220
*@version 09/09/2021
*/
import java.io.FileNotFoundException;
/**
*import java file not found functionality.
*/


public class CloudStoragePart2 {

   /**
   * constructor.
   *@param args not used.
   *@throws FileNotFoundException if the file cannot be opened.
   */
   public static void main(String[] args) throws FileNotFoundException {
      try {
         if (args.length > 0) {
    
            String fileName = args[0];
            CloudStorageList cloudList = new CloudStorageList();
            cloudList.readFile(fileName);
            System.out.println(cloudList.generateReport());
            System.out.println(cloudList.generateReportByName());
            System.out.println(cloudList.generateReportByMonthlyCost());
         }
      }
      
      catch (FileNotFoundException exception) {
         System.out.println("File name expected as command "
            + "line argument.\nProgram ending.");
      }      
   }
}